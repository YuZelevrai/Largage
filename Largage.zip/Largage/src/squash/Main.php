<?php

namespace squash;

use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\entity\Human;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use pocketmine\world\World;
use squash\entity\Largage;
use squash\tasks\LargageTask;

class Main extends PluginBase
{
    use SingletonTrait;

    protected function onLoad(): void
    {
        self::setInstance($this);

        if(!file_exists($this->getDataFolder() . "largage.geo.json")) {
            $this->saveResource("largage.geo.json");
        }
        if(!file_exists($this->getDataFolder() . "largage.png")) {
            $this->saveResource("largage.png");
        }

    }

    protected function onEnable(): void
    {
        $this->saveDefaultConfig();
        $this->getScheduler()->scheduleRepeatingTask(new LargageTask(), 20);

        /*EntityFactory::getInstance()->register(Largage::class, function (World $world, CompoundTag $nbt): Largage {
            return new Largage(EntityDataHelper::parseLocation($nbt, $world), Human::parseSkinNBT($nbt));
        }, ["Largage", "minecraft:largage"]);*/
    }
}