<?php

namespace squash\tasks;

use pocketmine\entity\Location;
use pocketmine\entity\Skin;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\scheduler\Task;
use pocketmine\Server;
use squash\entity\Largage;
use squash\Main;

class LargageTask extends Task
{

    public int $time;

    public array $prevention = [10, 5, 3];

    public function __construct()
    {
        $this->config = Main::getInstance()->getConfig();
        $this->time = $this->config->get('time-between-spawns');
    }


    /**
     * @throws \JsonException
     */
    public function onRun(): void
    {
        $this->time--;
        if ($this->time <= 0) {
            Server::getInstance()->broadcastMessage($this->config->getNested("drops-appeared") ?: "Les largages sont apparus.");

            $randomPositions = self::getRandomPositions(3);
            foreach ($randomPositions as $pos) {
                Server::getInstance()->broadcastMessage(str_replace(["{X}", "{Y}", "{Z}"], [$pos->x, 150, $pos->z], $this->config->getNested("drops-coordinates")));

                $skinData = self::PNGtoBYTES(Main::getInstance()->getDataFolder() . "largage.png");
                $geometryData = file_get_contents(Main::getInstance()->getDataFolder() . "largage.geo.json");

                $skin = new Skin("largage", $skinData,"","geometry.largage",$geometryData);
                $entity = new Largage(new Location($pos->x, 150, $pos->z, Server::getInstance()->getWorldManager()->getWorldByName( $this->config->getNested("world-area")), 0,0), $skin, new CompoundTag());
                $entity->spawnToAll();
            }


            $this->time = $this->config->get('time-between-spawns');
        } elseif (in_array($this->time, $this->prevention)) {
            Server::getInstance()->broadcastMessage(str_replace("{TIME}", $this->time, $this->config->getNested("countdown-appearance")) ?: "Les largages sont dans {$this->time}§f seconde(s).");
        }
    }

    public function getRandomPositions(int $count): array
    {
        $poss1 = explode(":",$this->config->getNested("first-corner-area"));
        $poss2 = explode(":",$this->config->getNested("second-corner-area"));

        $pos1 = new Vector3($poss1[0], $poss1[1], $poss1[2]);
        $pos2 = new Vector3($poss2[0], $poss2[1], $poss2[2]);

        $randomPositions = [];

        for ($i = 0; $i < $count; $i++) {
            $x = mt_rand(min($pos1->x, $pos2->x), max($pos1->x, $pos2->x));
            $y = mt_rand(min($pos1->y, $pos2->y), max($pos1->y, $pos2->y));
            $z = mt_rand(min($pos1->z, $pos2->z), max($pos1->z, $pos2->z));

            $randomPositions[] = new Vector3($x, $y, $z);
        }

        return $randomPositions;
    }

    public function PNGtoBYTES($path) : string
    {
        $img = @imagecreatefrompng($path);
        $bytes = "";
        $L = (int) @getimagesize($path)[0];
        $l = (int) @getimagesize($path)[1];
        for ($y = 0; $y < $l; $y++) {
            for ($x = 0; $x < $L; $x++) {
                $rgba = @imagecolorat($img, $x, $y);
                $a = ((~((int)($rgba >> 24))) << 1) & 0xff;
                $r = ($rgba >> 16) & 0xff;
                $g = ($rgba >> 8) & 0xff;
                $b = $rgba & 0xff;
                $bytes .= chr($r) . chr($g) . chr($b) . chr($a);
            }
        }
        @imagedestroy($img);
        return $bytes;
    }

}
