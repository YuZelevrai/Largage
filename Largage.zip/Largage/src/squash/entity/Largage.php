<?php

namespace squash\entity;

use pocketmine\entity\Human;
use pocketmine\entity\Location;
use pocketmine\entity\Skin;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\item\StringToItemParser;
use pocketmine\item\VanillaItems;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\player\Player;
use pocketmine\utils\Config;
use pocketmine\world\particle\HugeExplodeParticle;
use pocketmine\world\sound\ExplodeSound;
use squash\Main;

class Largage extends Human {

    public Config $config;

    public function __construct(Location $location, Skin $skin, ?CompoundTag $nbt = null)
    {
        $this->config = Main::getInstance()->getConfig();
        parent::__construct($location, $skin, $nbt);
    }

    private function updateNameTag(): void
    {
        $this->setNameTag(floor($this->getHealth()) . " §c❤");
        $this->setNameTagAlwaysVisible();
    }

    public function spawnToAll(): void
    {
        parent::spawnToAll();
        $this->setGravity(0.010);
        $this->updateNameTag();
    }

    public function getMaxHealth(): int
    {
        return $this->config->getNested("drops-life-point") ?: 30;
    }

    public function attack(EntityDamageEvent $source): void
    {
        if ($source instanceof EntityDamageByEntityEvent) {
            $damager = $source->getDamager();

            if ($damager instanceof Player) {
                $source->cancel();
                $updatedHp = $this->getHealth() - 1;

                if ($updatedHp > 0) {
                    $this->setHealth($updatedHp);
                    $this->updateNameTag();

                    return;
                }

                $this->close();

                $position = $this->getPosition();
                $world = $position->getWorld();

                $world->addParticle($position, new HugeExplodeParticle());
                $damager->broadcastSound(new ExplodeSound());


                $items = $this->config->getNested("items");

                foreach ($items as $itemData) {
                    $identifier = $itemData['identifier'];
                    $count = $itemData['count'];

                    $item = StringToItemParser::getInstance()->parse($identifier);
                    if ($item !== null) {
                        $item->setCount($count);

                        $pitch = mt_rand(0, 3);
                        $yaw = mt_rand(0, 360);

                        $droppedItem = $this->getWorld()->dropItem(
                            new Vector3($this->getPosition()->x, $this->getPosition()->y, $this->getPosition()->z),
                            $item
                        );

                        $droppedItem->setMotion(new Vector3(
                            -sin($yaw / 45 * M_PI) * cos($pitch / 45 * M_PI),
                            -sin($pitch / 45 * M_PI) * 0.2 + 1,
                            cos($yaw / 45 * M_PI) * cos($pitch / 45 * M_PI)
                        ));
                    }
                }
            }
        }
    }

    protected function initEntity(CompoundTag $nbt): void
    {
        parent::initEntity($nbt);
        $this->setGravity(0.010);
        $this->setHealth($this->getMaxHealth());
    }


}